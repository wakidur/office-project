'use strict';
angular.module('cricketInfo', ['ngMaterial','ngAnimate','ui.router']);

